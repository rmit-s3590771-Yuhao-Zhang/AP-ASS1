package com.APass1.rmit;

public class Swimmer extends Athlete{
	public Swimmer(String ID, String name, int age, String state){
		super(ID, name, age, state);
	}
}
