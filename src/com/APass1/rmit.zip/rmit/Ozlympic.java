package com.APass1.rmit;

public class Ozlympic {

	public static void main(String[] args) {
		Driver myDriver = new Driver();
		myDriver.runGame();

	}

}
