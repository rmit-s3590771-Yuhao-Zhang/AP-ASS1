package com.APass1.rmit;

public class Sprinter extends Athlete{
	public Sprinter(String ID, String name, int age, String state){
		super(ID, name, age, state);
	}
}
