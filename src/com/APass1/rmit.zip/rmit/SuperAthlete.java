package com.APass1.rmit;

public class SuperAthlete extends Athlete{
	public SuperAthlete(String ID, String name, int age, String state){
		super(ID, name, age, state);
	}
}