package com.APass1.rmit;

public class Cyclist extends Athlete{
	public Cyclist(String ID, String name, int age, String state){
		super(ID, name, age, state);
	}
}
